<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Startmin - Bootstrap Admin Theme</title>

        <!-- Bootstrap Core CSS -->
        <link href="css/admin/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="css/admin/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="css/admin/startmin.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="css/admin/font-awesome.min.css" rel="stylesheet" type="text/css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>

        <div id="wrapper">

            <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <div class="navbar-header">
                    <a class="navbar-brand" href="index">Startmin</a>
                </div>

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <ul class="nav navbar-nav navbar-left navbar-top-links">
                    <li><a href="#"><i class="fa fa-home fa-fw"></i> Website</a></li>
                </ul>

                <ul class="nav navbar-right navbar-top-links">
                    <li class="dropdown navbar-inverse">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-bell fa-fw"></i> <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu dropdown-alerts">
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="fa fa-comment fa-fw"></i> New Comment
                                        <span class="pull-right text-muted small">4 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="fa fa-twitter fa-fw"></i> 3 New Followers
                                        <span class="pull-right text-muted small">12 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="fa fa-envelope fa-fw"></i> Message Sent
                                        <span class="pull-right text-muted small">4 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="fa fa-tasks fa-fw"></i> New Task
                                        <span class="pull-right text-muted small">4 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="fa fa-upload fa-fw"></i> Server Rebooted
                                        <span class="pull-right text-muted small">4 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a class="text-center" href="#">
                                    <strong>See All Alerts</strong>
                                    <i class="fa fa-angle-right"></i>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-user fa-fw"></i> secondtruth <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                            <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                            </li>
                            <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                            </li>
                            <li class="divider"></li>
                            <li><a href="login"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                            <li class="sidebar-search">
                                <div class="input-group custom-search-form">
                                    <input type="text" class="form-control" placeholder="Search...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-primary" type="button">
                                            <i class="fa fa-search"></i>
                                        </button>
                                </span>
                                </div>
                                <!-- /input-group -->
                            </li>
                            <li>
                                <a href="index"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Charts<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="flot">Flot Charts</a>
                                    </li>
                                    <li>
                                        <a href="morris">Morris.js Charts</a>
                                    </li>
                                </ul>
                                <!-- /.nav-second-level -->
                            </li>
                            <li>
                                <a href="tables"><i class="fa fa-table fa-fw"></i> Tables</a>
                            </li>
                            <li>
                                <a href="forms"><i class="fa fa-edit fa-fw"></i> Forms</a>
                            </li>
                            <li class="active">
                                <a href="#"><i class="fa fa-wrench fa-fw"></i> UI Elements<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="panels-wells">Panels and Wells</a>
                                    </li>
                                    <li>
                                        <a href="buttons">Buttons</a>
                                    </li>
                                    <li>
                                        <a href="notifications">Notifications</a>
                                    </li>
                                    <li>
                                        <a href="typography">Typography</a>
                                    </li>
                                    <li>
                                        <a href="icons" class="active"> Icons</a>
                                    </li>
                                    <li>
                                        <a href="grid">Grid</a>
                                    </li>
                                </ul>
                                <!-- /.nav-second-level -->
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-sitemap fa-fw"></i> Multi-Level Dropdown<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="#">Second Level Item</a>
                                    </li>
                                    <li>
                                        <a href="#">Second Level Item</a>
                                    </li>
                                    <li>
                                        <a href="#">Third Level <span class="fa arrow"></span></a>
                                        <ul class="nav nav-third-level">
                                            <li>
                                                <a href="#">Third Level Item</a>
                                            </li>
                                            <li>
                                                <a href="#">Third Level Item</a>
                                            </li>
                                            <li>
                                                <a href="#">Third Level Item</a>
                                            </li>
                                            <li>
                                                <a href="#">Third Level Item</a>
                                            </li>
                                        </ul>
                                        <!-- /.nav-third-level -->
                                    </li>
                                </ul>
                                <!-- /.nav-second-level -->
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-files-o fa-fw"></i> Sample Pages<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="blank">Blank Page</a>
                                    </li>
                                    <li>
                                        <a href="login">Login Page</a>
                                    </li>
                                </ul>
                                <!-- /.nav-second-level -->
                            </li>
                        </ul>
                    </div>
                    <!-- /.sidebar-collapse -->
                </div>
                <!-- /.navbar-static-side -->
            </nav>

            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Icons</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                All available icons
                            </div>
                            <div class="panel-body">

                                <div class="row">



                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use 500px">&#xf26e</i>
                                        fa-500px

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use adjust">&#xf042</i>
                                        fa-adjust

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use adn">&#xf170</i>
                                        fa-adn

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use align-center">&#xf037</i>
                                        fa-align-center

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use align-justify">&#xf039</i>
                                        fa-align-justify

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use align-left">&#xf036</i>
                                        fa-align-left

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use align-right">&#xf038</i>
                                        fa-align-right

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use amazon">&#xf270</i>
                                        fa-amazon

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use ambulance">&#xf0f9</i>
                                        fa-ambulance

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use american-sign-language-interpreting">&#xf2a3</i>
                                        fa-american-sign-language-interpreting

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use anchor">&#xf13d</i>
                                        fa-anchor

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use android">&#xf17b</i>
                                        fa-android

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use angellist">&#xf209</i>
                                        fa-angellist

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use angle-double-down">&#xf103</i>
                                        fa-angle-double-down

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use angle-double-left">&#xf100</i>
                                        fa-angle-double-left

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use angle-double-right">&#xf101</i>
                                        fa-angle-double-right

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use angle-double-up">&#xf102</i>
                                        fa-angle-double-up

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use angle-down">&#xf107</i>
                                        fa-angle-down

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use angle-left">&#xf104</i>
                                        fa-angle-left

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use angle-right">&#xf105</i>
                                        fa-angle-right

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use angle-up">&#xf106</i>
                                        fa-angle-up

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use apple">&#xf179</i>
                                        fa-apple

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use archive">&#xf187</i>
                                        fa-archive

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use area-chart">&#xf1fe</i>
                                        fa-area-chart

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use arrow-circle-down">&#xf0ab</i>
                                        fa-arrow-circle-down

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use arrow-circle-left">&#xf0a8</i>
                                        fa-arrow-circle-left

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use arrow-circle-o-down">&#xf01a</i>
                                        fa-arrow-circle-o-down

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use arrow-circle-o-left">&#xf190</i>
                                        fa-arrow-circle-o-left

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use arrow-circle-o-right">&#xf18e</i>
                                        fa-arrow-circle-o-right

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use arrow-circle-o-up">&#xf01b</i>
                                        fa-arrow-circle-o-up

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use arrow-circle-right">&#xf0a9</i>
                                        fa-arrow-circle-right

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use arrow-circle-up">&#xf0aa</i>
                                        fa-arrow-circle-up

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use arrow-down">&#xf063</i>
                                        fa-arrow-down

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use arrow-left">&#xf060</i>
                                        fa-arrow-left

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use arrow-right">&#xf061</i>
                                        fa-arrow-right

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use arrow-up">&#xf062</i>
                                        fa-arrow-up

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use arrows">&#xf047</i>
                                        fa-arrows

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use arrows-alt">&#xf0b2</i>
                                        fa-arrows-alt

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use arrows-h">&#xf07e</i>
                                        fa-arrows-h

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use arrows-v">&#xf07d</i>
                                        fa-arrows-v

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use asl-interpreting">&#xf2a3</i>
                                        fa-asl-interpreting
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use assistive-listening-systems">&#xf2a2</i>
                                        fa-assistive-listening-systems

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use asterisk">&#xf069</i>
                                        fa-asterisk

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use at">&#xf1fa</i>
                                        fa-at

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use audio-description">&#xf29e</i>
                                        fa-audio-description

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use automobile">&#xf1b9</i>
                                        fa-automobile
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use backward">&#xf04a</i>
                                        fa-backward

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use balance-scale">&#xf24e</i>
                                        fa-balance-scale

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use ban">&#xf05e</i>
                                        fa-ban

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bank">&#xf19c</i>
                                        fa-bank
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bar-chart">&#xf080</i>
                                        fa-bar-chart

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bar-chart-o">&#xf080</i>
                                        fa-bar-chart-o
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use barcode">&#xf02a</i>
                                        fa-barcode

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bars">&#xf0c9</i>
                                        fa-bars

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use battery-0">&#xf244</i>
                                        fa-battery-0
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use battery-1">&#xf243</i>
                                        fa-battery-1
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use battery-2">&#xf242</i>
                                        fa-battery-2
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use battery-3">&#xf241</i>
                                        fa-battery-3
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use battery-4">&#xf240</i>
                                        fa-battery-4
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use battery-empty">&#xf244</i>
                                        fa-battery-empty

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use battery-full">&#xf240</i>
                                        fa-battery-full

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use battery-half">&#xf242</i>
                                        fa-battery-half

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use battery-quarter">&#xf243</i>
                                        fa-battery-quarter

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use battery-three-quarters">&#xf241</i>
                                        fa-battery-three-quarters

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bed">&#xf236</i>
                                        fa-bed

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use beer">&#xf0fc</i>
                                        fa-beer

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use behance">&#xf1b4</i>
                                        fa-behance

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use behance-square">&#xf1b5</i>
                                        fa-behance-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bell">&#xf0f3</i>
                                        fa-bell

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bell-o">&#xf0a2</i>
                                        fa-bell-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bell-slash">&#xf1f6</i>
                                        fa-bell-slash

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bell-slash-o">&#xf1f7</i>
                                        fa-bell-slash-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bicycle">&#xf206</i>
                                        fa-bicycle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use binoculars">&#xf1e5</i>
                                        fa-binoculars

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use birthday-cake">&#xf1fd</i>
                                        fa-birthday-cake

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bitbucket">&#xf171</i>
                                        fa-bitbucket

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bitbucket-square">&#xf172</i>
                                        fa-bitbucket-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bitcoin">&#xf15a</i>
                                        fa-bitcoin
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use black-tie">&#xf27e</i>
                                        fa-black-tie

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use blind">&#xf29d</i>
                                        fa-blind

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bluetooth">&#xf293</i>
                                        fa-bluetooth

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bluetooth-b">&#xf294</i>
                                        fa-bluetooth-b

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bold">&#xf032</i>
                                        fa-bold

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bolt">&#xf0e7</i>
                                        fa-bolt

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bomb">&#xf1e2</i>
                                        fa-bomb

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use book">&#xf02d</i>
                                        fa-book

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bookmark">&#xf02e</i>
                                        fa-bookmark

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bookmark-o">&#xf097</i>
                                        fa-bookmark-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use braille">&#xf2a1</i>
                                        fa-braille

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use briefcase">&#xf0b1</i>
                                        fa-briefcase

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use btc">&#xf15a</i>
                                        fa-btc

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bug">&#xf188</i>
                                        fa-bug

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use building">&#xf1ad</i>
                                        fa-building

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use building-o">&#xf0f7</i>
                                        fa-building-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bullhorn">&#xf0a1</i>
                                        fa-bullhorn

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bullseye">&#xf140</i>
                                        fa-bullseye

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use bus">&#xf207</i>
                                        fa-bus

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use buysellads">&#xf20d</i>
                                        fa-buysellads

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cab">&#xf1ba</i>
                                        fa-cab
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use calculator">&#xf1ec</i>
                                        fa-calculator

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use calendar">&#xf073</i>
                                        fa-calendar

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use calendar-check-o">&#xf274</i>
                                        fa-calendar-check-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use calendar-minus-o">&#xf272</i>
                                        fa-calendar-minus-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use calendar-o">&#xf133</i>
                                        fa-calendar-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use calendar-plus-o">&#xf271</i>
                                        fa-calendar-plus-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use calendar-times-o">&#xf273</i>
                                        fa-calendar-times-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use camera">&#xf030</i>
                                        fa-camera

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use camera-retro">&#xf083</i>
                                        fa-camera-retro

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use car">&#xf1b9</i>
                                        fa-car

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use caret-down">&#xf0d7</i>
                                        fa-caret-down

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use caret-left">&#xf0d9</i>
                                        fa-caret-left

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use caret-right">&#xf0da</i>
                                        fa-caret-right

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use caret-square-o-down">&#xf150</i>
                                        fa-caret-square-o-down

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use caret-square-o-left">&#xf191</i>
                                        fa-caret-square-o-left

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use caret-square-o-right">&#xf152</i>
                                        fa-caret-square-o-right

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use caret-square-o-up">&#xf151</i>
                                        fa-caret-square-o-up

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use caret-up">&#xf0d8</i>
                                        fa-caret-up

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cart-arrow-down">&#xf218</i>
                                        fa-cart-arrow-down

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cart-plus">&#xf217</i>
                                        fa-cart-plus

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cc">&#xf20a</i>
                                        fa-cc

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cc-amex">&#xf1f3</i>
                                        fa-cc-amex

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cc-diners-club">&#xf24c</i>
                                        fa-cc-diners-club

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cc-discover">&#xf1f2</i>
                                        fa-cc-discover

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cc-jcb">&#xf24b</i>
                                        fa-cc-jcb

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cc-mastercard">&#xf1f1</i>
                                        fa-cc-mastercard

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cc-paypal">&#xf1f4</i>
                                        fa-cc-paypal

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cc-stripe">&#xf1f5</i>
                                        fa-cc-stripe

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cc-visa">&#xf1f0</i>
                                        fa-cc-visa

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use certificate">&#xf0a3</i>
                                        fa-certificate

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use chain">&#xf0c1</i>
                                        fa-chain
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use chain-broken">&#xf127</i>
                                        fa-chain-broken

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use check">&#xf00c</i>
                                        fa-check

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use check-circle">&#xf058</i>
                                        fa-check-circle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use check-circle-o">&#xf05d</i>
                                        fa-check-circle-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use check-square">&#xf14a</i>
                                        fa-check-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use check-square-o">&#xf046</i>
                                        fa-check-square-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use chevron-circle-down">&#xf13a</i>
                                        fa-chevron-circle-down

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use chevron-circle-left">&#xf137</i>
                                        fa-chevron-circle-left

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use chevron-circle-right">&#xf138</i>
                                        fa-chevron-circle-right

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use chevron-circle-up">&#xf139</i>
                                        fa-chevron-circle-up

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use chevron-down">&#xf078</i>
                                        fa-chevron-down

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use chevron-left">&#xf053</i>
                                        fa-chevron-left

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use chevron-right">&#xf054</i>
                                        fa-chevron-right

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use chevron-up">&#xf077</i>
                                        fa-chevron-up

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use child">&#xf1ae</i>
                                        fa-child

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use chrome">&#xf268</i>
                                        fa-chrome

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use circle">&#xf111</i>
                                        fa-circle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use circle-o">&#xf10c</i>
                                        fa-circle-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use circle-o-notch">&#xf1ce</i>
                                        fa-circle-o-notch

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use circle-thin">&#xf1db</i>
                                        fa-circle-thin

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use clipboard">&#xf0ea</i>
                                        fa-clipboard

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use clock-o">&#xf017</i>
                                        fa-clock-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use clone">&#xf24d</i>
                                        fa-clone

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use close">&#xf00d</i>
                                        fa-close
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cloud">&#xf0c2</i>
                                        fa-cloud

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cloud-download">&#xf0ed</i>
                                        fa-cloud-download

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cloud-upload">&#xf0ee</i>
                                        fa-cloud-upload

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cny">&#xf157</i>
                                        fa-cny
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use code">&#xf121</i>
                                        fa-code

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use code-fork">&#xf126</i>
                                        fa-code-fork

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use codepen">&#xf1cb</i>
                                        fa-codepen

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use codiepie">&#xf284</i>
                                        fa-codiepie

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use coffee">&#xf0f4</i>
                                        fa-coffee

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cog">&#xf013</i>
                                        fa-cog

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cogs">&#xf085</i>
                                        fa-cogs

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use columns">&#xf0db</i>
                                        fa-columns

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use comment">&#xf075</i>
                                        fa-comment

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use comment-o">&#xf0e5</i>
                                        fa-comment-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use commenting">&#xf27a</i>
                                        fa-commenting

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use commenting-o">&#xf27b</i>
                                        fa-commenting-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use comments">&#xf086</i>
                                        fa-comments

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use comments-o">&#xf0e6</i>
                                        fa-comments-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use compass">&#xf14e</i>
                                        fa-compass

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use compress">&#xf066</i>
                                        fa-compress

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use connectdevelop">&#xf20e</i>
                                        fa-connectdevelop

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use contao">&#xf26d</i>
                                        fa-contao

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use copy">&#xf0c5</i>
                                        fa-copy
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use copyright">&#xf1f9</i>
                                        fa-copyright

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use creative-commons">&#xf25e</i>
                                        fa-creative-commons

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use credit-card">&#xf09d</i>
                                        fa-credit-card

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use credit-card-alt">&#xf283</i>
                                        fa-credit-card-alt

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use crop">&#xf125</i>
                                        fa-crop

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use crosshairs">&#xf05b</i>
                                        fa-crosshairs

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use css3">&#xf13c</i>
                                        fa-css3

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cube">&#xf1b2</i>
                                        fa-cube

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cubes">&#xf1b3</i>
                                        fa-cubes

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cut">&#xf0c4</i>
                                        fa-cut
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use cutlery">&#xf0f5</i>
                                        fa-cutlery

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use dashboard">&#xf0e4</i>
                                        fa-dashboard
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use dashcube">&#xf210</i>
                                        fa-dashcube

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use database">&#xf1c0</i>
                                        fa-database

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use deaf">&#xf2a4</i>
                                        fa-deaf

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use deafness">&#xf2a4</i>
                                        fa-deafness
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use dedent">&#xf03b</i>
                                        fa-dedent
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use delicious">&#xf1a5</i>
                                        fa-delicious

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use desktop">&#xf108</i>
                                        fa-desktop

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use deviantart">&#xf1bd</i>
                                        fa-deviantart

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use diamond">&#xf219</i>
                                        fa-diamond

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use digg">&#xf1a6</i>
                                        fa-digg

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use dollar">&#xf155</i>
                                        fa-dollar
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use dot-circle-o">&#xf192</i>
                                        fa-dot-circle-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use download">&#xf019</i>
                                        fa-download

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use dribbble">&#xf17d</i>
                                        fa-dribbble

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use dropbox">&#xf16b</i>
                                        fa-dropbox

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use drupal">&#xf1a9</i>
                                        fa-drupal

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use edge">&#xf282</i>
                                        fa-edge

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use edit">&#xf044</i>
                                        fa-edit
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use eject">&#xf052</i>
                                        fa-eject

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use ellipsis-h">&#xf141</i>
                                        fa-ellipsis-h

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use ellipsis-v">&#xf142</i>
                                        fa-ellipsis-v

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use empire">&#xf1d1</i>
                                        fa-empire

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use envelope">&#xf0e0</i>
                                        fa-envelope

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use envelope-o">&#xf003</i>
                                        fa-envelope-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use envelope-square">&#xf199</i>
                                        fa-envelope-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use envira">&#xf299</i>
                                        fa-envira

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use eraser">&#xf12d</i>
                                        fa-eraser

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use eur">&#xf153</i>
                                        fa-eur

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use euro">&#xf153</i>
                                        fa-euro
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use exchange">&#xf0ec</i>
                                        fa-exchange

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use exclamation">&#xf12a</i>
                                        fa-exclamation

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use exclamation-circle">&#xf06a</i>
                                        fa-exclamation-circle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use exclamation-triangle">&#xf071</i>
                                        fa-exclamation-triangle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use expand">&#xf065</i>
                                        fa-expand

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use expeditedssl">&#xf23e</i>
                                        fa-expeditedssl

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use external-link">&#xf08e</i>
                                        fa-external-link

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use external-link-square">&#xf14c</i>
                                        fa-external-link-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use eye">&#xf06e</i>
                                        fa-eye

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use eye-slash">&#xf070</i>
                                        fa-eye-slash

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use eyedropper">&#xf1fb</i>
                                        fa-eyedropper

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use fa">&#xf2b4</i>
                                        fa-fa
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use facebook">&#xf09a</i>
                                        fa-facebook

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use facebook-f">&#xf09a</i>
                                        fa-facebook-f
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use facebook-official">&#xf230</i>
                                        fa-facebook-official

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use facebook-square">&#xf082</i>
                                        fa-facebook-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use fast-backward">&#xf049</i>
                                        fa-fast-backward

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use fast-forward">&#xf050</i>
                                        fa-fast-forward

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use fax">&#xf1ac</i>
                                        fa-fax

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use feed">&#xf09e</i>
                                        fa-feed
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use female">&#xf182</i>
                                        fa-female

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use fighter-jet">&#xf0fb</i>
                                        fa-fighter-jet

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use file">&#xf15b</i>
                                        fa-file

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use file-archive-o">&#xf1c6</i>
                                        fa-file-archive-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use file-audio-o">&#xf1c7</i>
                                        fa-file-audio-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use file-code-o">&#xf1c9</i>
                                        fa-file-code-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use file-excel-o">&#xf1c3</i>
                                        fa-file-excel-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use file-image-o">&#xf1c5</i>
                                        fa-file-image-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use file-movie-o">&#xf1c8</i>
                                        fa-file-movie-o
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use file-o">&#xf016</i>
                                        fa-file-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use file-pdf-o">&#xf1c1</i>
                                        fa-file-pdf-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use file-photo-o">&#xf1c5</i>
                                        fa-file-photo-o
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use file-picture-o">&#xf1c5</i>
                                        fa-file-picture-o
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use file-powerpoint-o">&#xf1c4</i>
                                        fa-file-powerpoint-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use file-sound-o">&#xf1c7</i>
                                        fa-file-sound-o
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use file-text">&#xf15c</i>
                                        fa-file-text

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use file-text-o">&#xf0f6</i>
                                        fa-file-text-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use file-video-o">&#xf1c8</i>
                                        fa-file-video-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use file-word-o">&#xf1c2</i>
                                        fa-file-word-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use file-zip-o">&#xf1c6</i>
                                        fa-file-zip-o
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use files-o">&#xf0c5</i>
                                        fa-files-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use film">&#xf008</i>
                                        fa-film

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use filter">&#xf0b0</i>
                                        fa-filter

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use fire">&#xf06d</i>
                                        fa-fire

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use fire-extinguisher">&#xf134</i>
                                        fa-fire-extinguisher

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use firefox">&#xf269</i>
                                        fa-firefox

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use first-order">&#xf2b0</i>
                                        fa-first-order

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use flag">&#xf024</i>
                                        fa-flag

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use flag-checkered">&#xf11e</i>
                                        fa-flag-checkered

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use flag-o">&#xf11d</i>
                                        fa-flag-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use flash">&#xf0e7</i>
                                        fa-flash
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use flask">&#xf0c3</i>
                                        fa-flask

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use flickr">&#xf16e</i>
                                        fa-flickr

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use floppy-o">&#xf0c7</i>
                                        fa-floppy-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use folder">&#xf07b</i>
                                        fa-folder

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use folder-o">&#xf114</i>
                                        fa-folder-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use folder-open">&#xf07c</i>
                                        fa-folder-open

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use folder-open-o">&#xf115</i>
                                        fa-folder-open-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use font">&#xf031</i>
                                        fa-font

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use font-awesome">&#xf2b4</i>
                                        fa-font-awesome

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use fonticons">&#xf280</i>
                                        fa-fonticons

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use fort-awesome">&#xf286</i>
                                        fa-fort-awesome

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use forumbee">&#xf211</i>
                                        fa-forumbee

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use forward">&#xf04e</i>
                                        fa-forward

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use foursquare">&#xf180</i>
                                        fa-foursquare

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use frown-o">&#xf119</i>
                                        fa-frown-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use futbol-o">&#xf1e3</i>
                                        fa-futbol-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use gamepad">&#xf11b</i>
                                        fa-gamepad

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use gavel">&#xf0e3</i>
                                        fa-gavel

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use gbp">&#xf154</i>
                                        fa-gbp

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use ge">&#xf1d1</i>
                                        fa-ge
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use gear">&#xf013</i>
                                        fa-gear
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use gears">&#xf085</i>
                                        fa-gears
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use genderless">&#xf22d</i>
                                        fa-genderless

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use get-pocket">&#xf265</i>
                                        fa-get-pocket

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use gg">&#xf260</i>
                                        fa-gg

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use gg-circle">&#xf261</i>
                                        fa-gg-circle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use gift">&#xf06b</i>
                                        fa-gift

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use git">&#xf1d3</i>
                                        fa-git

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use git-square">&#xf1d2</i>
                                        fa-git-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use github">&#xf09b</i>
                                        fa-github

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use github-alt">&#xf113</i>
                                        fa-github-alt

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use github-square">&#xf092</i>
                                        fa-github-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use gitlab">&#xf296</i>
                                        fa-gitlab

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use gittip">&#xf184</i>
                                        fa-gittip
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use glass">&#xf000</i>
                                        fa-glass

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use glide">&#xf2a5</i>
                                        fa-glide

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use glide-g">&#xf2a6</i>
                                        fa-glide-g

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use globe">&#xf0ac</i>
                                        fa-globe

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use google">&#xf1a0</i>
                                        fa-google

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use google-plus">&#xf0d5</i>
                                        fa-google-plus

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use google-plus-circle">&#xf2b3</i>
                                        fa-google-plus-circle
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use google-plus-official">&#xf2b3</i>
                                        fa-google-plus-official

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use google-plus-square">&#xf0d4</i>
                                        fa-google-plus-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use google-wallet">&#xf1ee</i>
                                        fa-google-wallet

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use graduation-cap">&#xf19d</i>
                                        fa-graduation-cap

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use gratipay">&#xf184</i>
                                        fa-gratipay

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use group">&#xf0c0</i>
                                        fa-group
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use h-square">&#xf0fd</i>
                                        fa-h-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hacker-news">&#xf1d4</i>
                                        fa-hacker-news

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hand-grab-o">&#xf255</i>
                                        fa-hand-grab-o
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hand-lizard-o">&#xf258</i>
                                        fa-hand-lizard-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hand-o-down">&#xf0a7</i>
                                        fa-hand-o-down

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hand-o-left">&#xf0a5</i>
                                        fa-hand-o-left

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hand-o-right">&#xf0a4</i>
                                        fa-hand-o-right

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hand-o-up">&#xf0a6</i>
                                        fa-hand-o-up

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hand-paper-o">&#xf256</i>
                                        fa-hand-paper-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hand-peace-o">&#xf25b</i>
                                        fa-hand-peace-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hand-pointer-o">&#xf25a</i>
                                        fa-hand-pointer-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hand-rock-o">&#xf255</i>
                                        fa-hand-rock-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hand-scissors-o">&#xf257</i>
                                        fa-hand-scissors-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hand-spock-o">&#xf259</i>
                                        fa-hand-spock-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hand-stop-o">&#xf256</i>
                                        fa-hand-stop-o
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hard-of-hearing">&#xf2a4</i>
                                        fa-hard-of-hearing
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hashtag">&#xf292</i>
                                        fa-hashtag

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hdd-o">&#xf0a0</i>
                                        fa-hdd-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use header">&#xf1dc</i>
                                        fa-header

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use headphones">&#xf025</i>
                                        fa-headphones

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use heart">&#xf004</i>
                                        fa-heart

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use heart-o">&#xf08a</i>
                                        fa-heart-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use heartbeat">&#xf21e</i>
                                        fa-heartbeat

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use history">&#xf1da</i>
                                        fa-history

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use home">&#xf015</i>
                                        fa-home

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hospital-o">&#xf0f8</i>
                                        fa-hospital-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hotel">&#xf236</i>
                                        fa-hotel
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hourglass">&#xf254</i>
                                        fa-hourglass

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hourglass-1">&#xf251</i>
                                        fa-hourglass-1
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hourglass-2">&#xf252</i>
                                        fa-hourglass-2
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hourglass-3">&#xf253</i>
                                        fa-hourglass-3
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hourglass-end">&#xf253</i>
                                        fa-hourglass-end

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hourglass-half">&#xf252</i>
                                        fa-hourglass-half

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hourglass-o">&#xf250</i>
                                        fa-hourglass-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use hourglass-start">&#xf251</i>
                                        fa-hourglass-start

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use houzz">&#xf27c</i>
                                        fa-houzz

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use html5">&#xf13b</i>
                                        fa-html5

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use i-cursor">&#xf246</i>
                                        fa-i-cursor

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use ils">&#xf20b</i>
                                        fa-ils

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use image">&#xf03e</i>
                                        fa-image
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use inbox">&#xf01c</i>
                                        fa-inbox

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use indent">&#xf03c</i>
                                        fa-indent

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use industry">&#xf275</i>
                                        fa-industry

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use info">&#xf129</i>
                                        fa-info

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use info-circle">&#xf05a</i>
                                        fa-info-circle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use inr">&#xf156</i>
                                        fa-inr

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use instagram">&#xf16d</i>
                                        fa-instagram

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use institution">&#xf19c</i>
                                        fa-institution
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use internet-explorer">&#xf26b</i>
                                        fa-internet-explorer

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use intersex">&#xf224</i>
                                        fa-intersex
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use ioxhost">&#xf208</i>
                                        fa-ioxhost

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use italic">&#xf033</i>
                                        fa-italic

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use joomla">&#xf1aa</i>
                                        fa-joomla

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use jpy">&#xf157</i>
                                        fa-jpy

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use jsfiddle">&#xf1cc</i>
                                        fa-jsfiddle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use key">&#xf084</i>
                                        fa-key

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use keyboard-o">&#xf11c</i>
                                        fa-keyboard-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use krw">&#xf159</i>
                                        fa-krw

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use language">&#xf1ab</i>
                                        fa-language

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use laptop">&#xf109</i>
                                        fa-laptop

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use lastfm">&#xf202</i>
                                        fa-lastfm

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use lastfm-square">&#xf203</i>
                                        fa-lastfm-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use leaf">&#xf06c</i>
                                        fa-leaf

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use leanpub">&#xf212</i>
                                        fa-leanpub

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use legal">&#xf0e3</i>
                                        fa-legal
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use lemon-o">&#xf094</i>
                                        fa-lemon-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use level-down">&#xf149</i>
                                        fa-level-down

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use level-up">&#xf148</i>
                                        fa-level-up

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use life-bouy">&#xf1cd</i>
                                        fa-life-bouy
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use life-buoy">&#xf1cd</i>
                                        fa-life-buoy
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use life-ring">&#xf1cd</i>
                                        fa-life-ring

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use life-saver">&#xf1cd</i>
                                        fa-life-saver
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use lightbulb-o">&#xf0eb</i>
                                        fa-lightbulb-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use line-chart">&#xf201</i>
                                        fa-line-chart

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use link">&#xf0c1</i>
                                        fa-link

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use linkedin">&#xf0e1</i>
                                        fa-linkedin

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use linkedin-square">&#xf08c</i>
                                        fa-linkedin-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use linux">&#xf17c</i>
                                        fa-linux

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use list">&#xf03a</i>
                                        fa-list

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use list-alt">&#xf022</i>
                                        fa-list-alt

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use list-ol">&#xf0cb</i>
                                        fa-list-ol

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use list-ul">&#xf0ca</i>
                                        fa-list-ul

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use location-arrow">&#xf124</i>
                                        fa-location-arrow

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use lock">&#xf023</i>
                                        fa-lock

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use long-arrow-down">&#xf175</i>
                                        fa-long-arrow-down

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use long-arrow-left">&#xf177</i>
                                        fa-long-arrow-left

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use long-arrow-right">&#xf178</i>
                                        fa-long-arrow-right

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use long-arrow-up">&#xf176</i>
                                        fa-long-arrow-up

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use low-vision">&#xf2a8</i>
                                        fa-low-vision

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use magic">&#xf0d0</i>
                                        fa-magic

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use magnet">&#xf076</i>
                                        fa-magnet

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use mail-forward">&#xf064</i>
                                        fa-mail-forward
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use mail-reply">&#xf112</i>
                                        fa-mail-reply
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use mail-reply-all">&#xf122</i>
                                        fa-mail-reply-all
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use male">&#xf183</i>
                                        fa-male

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use map">&#xf279</i>
                                        fa-map

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use map-marker">&#xf041</i>
                                        fa-map-marker

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use map-o">&#xf278</i>
                                        fa-map-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use map-pin">&#xf276</i>
                                        fa-map-pin

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use map-signs">&#xf277</i>
                                        fa-map-signs

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use mars">&#xf222</i>
                                        fa-mars

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use mars-double">&#xf227</i>
                                        fa-mars-double

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use mars-stroke">&#xf229</i>
                                        fa-mars-stroke

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use mars-stroke-h">&#xf22b</i>
                                        fa-mars-stroke-h

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use mars-stroke-v">&#xf22a</i>
                                        fa-mars-stroke-v

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use maxcdn">&#xf136</i>
                                        fa-maxcdn

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use meanpath">&#xf20c</i>
                                        fa-meanpath

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use medium">&#xf23a</i>
                                        fa-medium

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use medkit">&#xf0fa</i>
                                        fa-medkit

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use meh-o">&#xf11a</i>
                                        fa-meh-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use mercury">&#xf223</i>
                                        fa-mercury

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use microphone">&#xf130</i>
                                        fa-microphone

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use microphone-slash">&#xf131</i>
                                        fa-microphone-slash

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use minus">&#xf068</i>
                                        fa-minus

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use minus-circle">&#xf056</i>
                                        fa-minus-circle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use minus-square">&#xf146</i>
                                        fa-minus-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use minus-square-o">&#xf147</i>
                                        fa-minus-square-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use mixcloud">&#xf289</i>
                                        fa-mixcloud

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use mobile">&#xf10b</i>
                                        fa-mobile

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use mobile-phone">&#xf10b</i>
                                        fa-mobile-phone
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use modx">&#xf285</i>
                                        fa-modx

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use money">&#xf0d6</i>
                                        fa-money

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use moon-o">&#xf186</i>
                                        fa-moon-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use mortar-board">&#xf19d</i>
                                        fa-mortar-board
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use motorcycle">&#xf21c</i>
                                        fa-motorcycle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use mouse-pointer">&#xf245</i>
                                        fa-mouse-pointer

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use music">&#xf001</i>
                                        fa-music

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use navicon">&#xf0c9</i>
                                        fa-navicon
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use neuter">&#xf22c</i>
                                        fa-neuter

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use newspaper-o">&#xf1ea</i>
                                        fa-newspaper-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use object-group">&#xf247</i>
                                        fa-object-group

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use object-ungroup">&#xf248</i>
                                        fa-object-ungroup

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use odnoklassniki">&#xf263</i>
                                        fa-odnoklassniki

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use odnoklassniki-square">&#xf264</i>
                                        fa-odnoklassniki-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use opencart">&#xf23d</i>
                                        fa-opencart

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use openid">&#xf19b</i>
                                        fa-openid

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use opera">&#xf26a</i>
                                        fa-opera

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use optin-monster">&#xf23c</i>
                                        fa-optin-monster

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use outdent">&#xf03b</i>
                                        fa-outdent

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use pagelines">&#xf18c</i>
                                        fa-pagelines

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use paint-brush">&#xf1fc</i>
                                        fa-paint-brush

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use paper-plane">&#xf1d8</i>
                                        fa-paper-plane

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use paper-plane-o">&#xf1d9</i>
                                        fa-paper-plane-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use paperclip">&#xf0c6</i>
                                        fa-paperclip

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use paragraph">&#xf1dd</i>
                                        fa-paragraph

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use paste">&#xf0ea</i>
                                        fa-paste
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use pause">&#xf04c</i>
                                        fa-pause

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use pause-circle">&#xf28b</i>
                                        fa-pause-circle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use pause-circle-o">&#xf28c</i>
                                        fa-pause-circle-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use paw">&#xf1b0</i>
                                        fa-paw

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use paypal">&#xf1ed</i>
                                        fa-paypal

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use pencil">&#xf040</i>
                                        fa-pencil

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use pencil-square">&#xf14b</i>
                                        fa-pencil-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use pencil-square-o">&#xf044</i>
                                        fa-pencil-square-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use percent">&#xf295</i>
                                        fa-percent

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use phone">&#xf095</i>
                                        fa-phone

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use phone-square">&#xf098</i>
                                        fa-phone-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use photo">&#xf03e</i>
                                        fa-photo
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use picture-o">&#xf03e</i>
                                        fa-picture-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use pie-chart">&#xf200</i>
                                        fa-pie-chart

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use pied-piper">&#xf2ae</i>
                                        fa-pied-piper

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use pied-piper-alt">&#xf1a8</i>
                                        fa-pied-piper-alt

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use pied-piper-pp">&#xf1a7</i>
                                        fa-pied-piper-pp

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use pinterest">&#xf0d2</i>
                                        fa-pinterest

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use pinterest-p">&#xf231</i>
                                        fa-pinterest-p

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use pinterest-square">&#xf0d3</i>
                                        fa-pinterest-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use plane">&#xf072</i>
                                        fa-plane

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use play">&#xf04b</i>
                                        fa-play

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use play-circle">&#xf144</i>
                                        fa-play-circle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use play-circle-o">&#xf01d</i>
                                        fa-play-circle-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use plug">&#xf1e6</i>
                                        fa-plug

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use plus">&#xf067</i>
                                        fa-plus

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use plus-circle">&#xf055</i>
                                        fa-plus-circle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use plus-square">&#xf0fe</i>
                                        fa-plus-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use plus-square-o">&#xf196</i>
                                        fa-plus-square-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use power-off">&#xf011</i>
                                        fa-power-off

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use print">&#xf02f</i>
                                        fa-print

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use product-hunt">&#xf288</i>
                                        fa-product-hunt

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use puzzle-piece">&#xf12e</i>
                                        fa-puzzle-piece

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use qq">&#xf1d6</i>
                                        fa-qq

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use qrcode">&#xf029</i>
                                        fa-qrcode

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use question">&#xf128</i>
                                        fa-question

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use question-circle">&#xf059</i>
                                        fa-question-circle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use question-circle-o">&#xf29c</i>
                                        fa-question-circle-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use quote-left">&#xf10d</i>
                                        fa-quote-left

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use quote-right">&#xf10e</i>
                                        fa-quote-right

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use ra">&#xf1d0</i>
                                        fa-ra
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use random">&#xf074</i>
                                        fa-random

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use rebel">&#xf1d0</i>
                                        fa-rebel

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use recycle">&#xf1b8</i>
                                        fa-recycle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use reddit">&#xf1a1</i>
                                        fa-reddit

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use reddit-alien">&#xf281</i>
                                        fa-reddit-alien

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use reddit-square">&#xf1a2</i>
                                        fa-reddit-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use refresh">&#xf021</i>
                                        fa-refresh

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use registered">&#xf25d</i>
                                        fa-registered

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use remove">&#xf00d</i>
                                        fa-remove
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use renren">&#xf18b</i>
                                        fa-renren

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use reorder">&#xf0c9</i>
                                        fa-reorder
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use repeat">&#xf01e</i>
                                        fa-repeat

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use reply">&#xf112</i>
                                        fa-reply

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use reply-all">&#xf122</i>
                                        fa-reply-all

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use resistance">&#xf1d0</i>
                                        fa-resistance
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use retweet">&#xf079</i>
                                        fa-retweet

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use rmb">&#xf157</i>
                                        fa-rmb
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use road">&#xf018</i>
                                        fa-road

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use rocket">&#xf135</i>
                                        fa-rocket

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use rotate-left">&#xf0e2</i>
                                        fa-rotate-left
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use rotate-right">&#xf01e</i>
                                        fa-rotate-right
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use rouble">&#xf158</i>
                                        fa-rouble
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use rss">&#xf09e</i>
                                        fa-rss

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use rss-square">&#xf143</i>
                                        fa-rss-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use rub">&#xf158</i>
                                        fa-rub

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use ruble">&#xf158</i>
                                        fa-ruble
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use rupee">&#xf156</i>
                                        fa-rupee
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use safari">&#xf267</i>
                                        fa-safari

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use save">&#xf0c7</i>
                                        fa-save
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use scissors">&#xf0c4</i>
                                        fa-scissors

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use scribd">&#xf28a</i>
                                        fa-scribd

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use search">&#xf002</i>
                                        fa-search

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use search-minus">&#xf010</i>
                                        fa-search-minus

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use search-plus">&#xf00e</i>
                                        fa-search-plus

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sellsy">&#xf213</i>
                                        fa-sellsy

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use send">&#xf1d8</i>
                                        fa-send
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use send-o">&#xf1d9</i>
                                        fa-send-o
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use server">&#xf233</i>
                                        fa-server

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use share">&#xf064</i>
                                        fa-share

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use share-alt">&#xf1e0</i>
                                        fa-share-alt

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use share-alt-square">&#xf1e1</i>
                                        fa-share-alt-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use share-square">&#xf14d</i>
                                        fa-share-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use share-square-o">&#xf045</i>
                                        fa-share-square-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use shekel">&#xf20b</i>
                                        fa-shekel
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sheqel">&#xf20b</i>
                                        fa-sheqel
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use shield">&#xf132</i>
                                        fa-shield

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use ship">&#xf21a</i>
                                        fa-ship

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use shirtsinbulk">&#xf214</i>
                                        fa-shirtsinbulk

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use shopping-bag">&#xf290</i>
                                        fa-shopping-bag

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use shopping-basket">&#xf291</i>
                                        fa-shopping-basket

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use shopping-cart">&#xf07a</i>
                                        fa-shopping-cart

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sign-in">&#xf090</i>
                                        fa-sign-in

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sign-language">&#xf2a7</i>
                                        fa-sign-language

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sign-out">&#xf08b</i>
                                        fa-sign-out

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use signal">&#xf012</i>
                                        fa-signal

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use signing">&#xf2a7</i>
                                        fa-signing
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use simplybuilt">&#xf215</i>
                                        fa-simplybuilt

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sitemap">&#xf0e8</i>
                                        fa-sitemap

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use skyatlas">&#xf216</i>
                                        fa-skyatlas

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use skype">&#xf17e</i>
                                        fa-skype

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use slack">&#xf198</i>
                                        fa-slack

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sliders">&#xf1de</i>
                                        fa-sliders

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use slideshare">&#xf1e7</i>
                                        fa-slideshare

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use smile-o">&#xf118</i>
                                        fa-smile-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use snapchat">&#xf2ab</i>
                                        fa-snapchat

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use snapchat-ghost">&#xf2ac</i>
                                        fa-snapchat-ghost

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use snapchat-square">&#xf2ad</i>
                                        fa-snapchat-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use soccer-ball-o">&#xf1e3</i>
                                        fa-soccer-ball-o
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sort">&#xf0dc</i>
                                        fa-sort

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sort-alpha-asc">&#xf15d</i>
                                        fa-sort-alpha-asc

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sort-alpha-desc">&#xf15e</i>
                                        fa-sort-alpha-desc

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sort-amount-asc">&#xf160</i>
                                        fa-sort-amount-asc

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sort-amount-desc">&#xf161</i>
                                        fa-sort-amount-desc

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sort-asc">&#xf0de</i>
                                        fa-sort-asc

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sort-desc">&#xf0dd</i>
                                        fa-sort-desc

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sort-down">&#xf0dd</i>
                                        fa-sort-down
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sort-numeric-asc">&#xf162</i>
                                        fa-sort-numeric-asc

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sort-numeric-desc">&#xf163</i>
                                        fa-sort-numeric-desc

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sort-up">&#xf0de</i>
                                        fa-sort-up
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use soundcloud">&#xf1be</i>
                                        fa-soundcloud

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use space-shuttle">&#xf197</i>
                                        fa-space-shuttle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use spinner">&#xf110</i>
                                        fa-spinner

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use spoon">&#xf1b1</i>
                                        fa-spoon

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use spotify">&#xf1bc</i>
                                        fa-spotify

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use square">&#xf0c8</i>
                                        fa-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use square-o">&#xf096</i>
                                        fa-square-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use stack-exchange">&#xf18d</i>
                                        fa-stack-exchange

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use stack-overflow">&#xf16c</i>
                                        fa-stack-overflow

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use star">&#xf005</i>
                                        fa-star

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use star-half">&#xf089</i>
                                        fa-star-half

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use star-half-empty">&#xf123</i>
                                        fa-star-half-empty
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use star-half-full">&#xf123</i>
                                        fa-star-half-full
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use star-half-o">&#xf123</i>
                                        fa-star-half-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use star-o">&#xf006</i>
                                        fa-star-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use steam">&#xf1b6</i>
                                        fa-steam

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use steam-square">&#xf1b7</i>
                                        fa-steam-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use step-backward">&#xf048</i>
                                        fa-step-backward

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use step-forward">&#xf051</i>
                                        fa-step-forward

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use stethoscope">&#xf0f1</i>
                                        fa-stethoscope

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sticky-note">&#xf249</i>
                                        fa-sticky-note

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sticky-note-o">&#xf24a</i>
                                        fa-sticky-note-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use stop">&#xf04d</i>
                                        fa-stop

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use stop-circle">&#xf28d</i>
                                        fa-stop-circle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use stop-circle-o">&#xf28e</i>
                                        fa-stop-circle-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use street-view">&#xf21d</i>
                                        fa-street-view

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use strikethrough">&#xf0cc</i>
                                        fa-strikethrough

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use stumbleupon">&#xf1a4</i>
                                        fa-stumbleupon

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use stumbleupon-circle">&#xf1a3</i>
                                        fa-stumbleupon-circle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use subscript">&#xf12c</i>
                                        fa-subscript

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use subway">&#xf239</i>
                                        fa-subway

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use suitcase">&#xf0f2</i>
                                        fa-suitcase

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use sun-o">&#xf185</i>
                                        fa-sun-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use superscript">&#xf12b</i>
                                        fa-superscript

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use support">&#xf1cd</i>
                                        fa-support
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use table">&#xf0ce</i>
                                        fa-table

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use tablet">&#xf10a</i>
                                        fa-tablet

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use tachometer">&#xf0e4</i>
                                        fa-tachometer

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use tag">&#xf02b</i>
                                        fa-tag

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use tags">&#xf02c</i>
                                        fa-tags

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use tasks">&#xf0ae</i>
                                        fa-tasks

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use taxi">&#xf1ba</i>
                                        fa-taxi

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use television">&#xf26c</i>
                                        fa-television

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use tencent-weibo">&#xf1d5</i>
                                        fa-tencent-weibo

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use terminal">&#xf120</i>
                                        fa-terminal

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use text-height">&#xf034</i>
                                        fa-text-height

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use text-width">&#xf035</i>
                                        fa-text-width

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use th">&#xf00a</i>
                                        fa-th

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use th-large">&#xf009</i>
                                        fa-th-large

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use th-list">&#xf00b</i>
                                        fa-th-list

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use themeisle">&#xf2b2</i>
                                        fa-themeisle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use thumb-tack">&#xf08d</i>
                                        fa-thumb-tack

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use thumbs-down">&#xf165</i>
                                        fa-thumbs-down

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use thumbs-o-down">&#xf088</i>
                                        fa-thumbs-o-down

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use thumbs-o-up">&#xf087</i>
                                        fa-thumbs-o-up

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use thumbs-up">&#xf164</i>
                                        fa-thumbs-up

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use ticket">&#xf145</i>
                                        fa-ticket

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use times">&#xf00d</i>
                                        fa-times

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use times-circle">&#xf057</i>
                                        fa-times-circle

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use times-circle-o">&#xf05c</i>
                                        fa-times-circle-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use tint">&#xf043</i>
                                        fa-tint

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use toggle-down">&#xf150</i>
                                        fa-toggle-down
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use toggle-left">&#xf191</i>
                                        fa-toggle-left
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use toggle-off">&#xf204</i>
                                        fa-toggle-off

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use toggle-on">&#xf205</i>
                                        fa-toggle-on

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use toggle-right">&#xf152</i>
                                        fa-toggle-right
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use toggle-up">&#xf151</i>
                                        fa-toggle-up
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use trademark">&#xf25c</i>
                                        fa-trademark

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use train">&#xf238</i>
                                        fa-train

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use transgender">&#xf224</i>
                                        fa-transgender

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use transgender-alt">&#xf225</i>
                                        fa-transgender-alt

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use trash">&#xf1f8</i>
                                        fa-trash

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use trash-o">&#xf014</i>
                                        fa-trash-o

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use tree">&#xf1bb</i>
                                        fa-tree

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use trello">&#xf181</i>
                                        fa-trello

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use tripadvisor">&#xf262</i>
                                        fa-tripadvisor

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use trophy">&#xf091</i>
                                        fa-trophy

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use truck">&#xf0d1</i>
                                        fa-truck

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use try">&#xf195</i>
                                        fa-try

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use tty">&#xf1e4</i>
                                        fa-tty

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use tumblr">&#xf173</i>
                                        fa-tumblr

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use tumblr-square">&#xf174</i>
                                        fa-tumblr-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use turkish-lira">&#xf195</i>
                                        fa-turkish-lira
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use tv">&#xf26c</i>
                                        fa-tv
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use twitch">&#xf1e8</i>
                                        fa-twitch

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use twitter">&#xf099</i>
                                        fa-twitter

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use twitter-square">&#xf081</i>
                                        fa-twitter-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use umbrella">&#xf0e9</i>
                                        fa-umbrella

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use underline">&#xf0cd</i>
                                        fa-underline

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use undo">&#xf0e2</i>
                                        fa-undo

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use universal-access">&#xf29a</i>
                                        fa-universal-access

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use university">&#xf19c</i>
                                        fa-university

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use unlink">&#xf127</i>
                                        fa-unlink
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use unlock">&#xf09c</i>
                                        fa-unlock

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use unlock-alt">&#xf13e</i>
                                        fa-unlock-alt

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use unsorted">&#xf0dc</i>
                                        fa-unsorted
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use upload">&#xf093</i>
                                        fa-upload

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use usb">&#xf287</i>
                                        fa-usb

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use usd">&#xf155</i>
                                        fa-usd

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use user">&#xf007</i>
                                        fa-user

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use user-md">&#xf0f0</i>
                                        fa-user-md

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use user-plus">&#xf234</i>
                                        fa-user-plus

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use user-secret">&#xf21b</i>
                                        fa-user-secret

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use user-times">&#xf235</i>
                                        fa-user-times

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use users">&#xf0c0</i>
                                        fa-users

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use venus">&#xf221</i>
                                        fa-venus

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use venus-double">&#xf226</i>
                                        fa-venus-double

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use venus-mars">&#xf228</i>
                                        fa-venus-mars

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use viacoin">&#xf237</i>
                                        fa-viacoin

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use viadeo">&#xf2a9</i>
                                        fa-viadeo

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use viadeo-square">&#xf2aa</i>
                                        fa-viadeo-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use video-camera">&#xf03d</i>
                                        fa-video-camera

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use vimeo">&#xf27d</i>
                                        fa-vimeo

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use vimeo-square">&#xf194</i>
                                        fa-vimeo-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use vine">&#xf1ca</i>
                                        fa-vine

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use vk">&#xf189</i>
                                        fa-vk

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use volume-control-phone">&#xf2a0</i>
                                        fa-volume-control-phone

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use volume-down">&#xf027</i>
                                        fa-volume-down

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use volume-off">&#xf026</i>
                                        fa-volume-off

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use volume-up">&#xf028</i>
                                        fa-volume-up

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use warning">&#xf071</i>
                                        fa-warning
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use wechat">&#xf1d7</i>
                                        fa-wechat
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use weibo">&#xf18a</i>
                                        fa-weibo

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use weixin">&#xf1d7</i>
                                        fa-weixin

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use whatsapp">&#xf232</i>
                                        fa-whatsapp

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use wheelchair">&#xf193</i>
                                        fa-wheelchair

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use wheelchair-alt">&#xf29b</i>
                                        fa-wheelchair-alt

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use wifi">&#xf1eb</i>
                                        fa-wifi

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use wikipedia-w">&#xf266</i>
                                        fa-wikipedia-w

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use windows">&#xf17a</i>
                                        fa-windows

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use won">&#xf159</i>
                                        fa-won
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use wordpress">&#xf19a</i>
                                        fa-wordpress

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use wpbeginner">&#xf297</i>
                                        fa-wpbeginner

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use wpforms">&#xf298</i>
                                        fa-wpforms

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use wrench">&#xf0ad</i>
                                        fa-wrench

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use xing">&#xf168</i>
                                        fa-xing

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use xing-square">&#xf169</i>
                                        fa-xing-square

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use y-combinator">&#xf23b</i>
                                        fa-y-combinator

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use y-combinator-square">&#xf1d4</i>
                                        fa-y-combinator-square
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use yahoo">&#xf19e</i>
                                        fa-yahoo

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use yc">&#xf23b</i>
                                        fa-yc
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use yc-square">&#xf1d4</i>
                                        fa-yc-square
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use yelp">&#xf1e9</i>
                                        fa-yelp

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use yen">&#xf157</i>
                                        fa-yen
                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">
                                        
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use yoast">&#xf2b1</i>
                                        fa-yoast

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use youtube">&#xf167</i>
                                        fa-youtube

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use youtube-play">&#xf16a</i>
                                        fa-youtube-play

                                    </div>

                                    <div class="col-md-4 col-sm-6 col-lg-3">

                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use youtube-square">&#xf166</i>
                                        fa-youtube-square

                                    </div>

                                </div>
                                <!-- /.row (nested) -->
                            </div>
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="{{ asset('js/admin/jquery.min.js') }}"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="{{ asset('js/admin/bootstrap.min.js') }}"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="{{ asset('js/admin/metisMenu.min.js') }}"></script>

        <!-- Custom Theme JavaScript -->
        <script src="{{ asset('js/admin/startmin.js') }}"></script>

    </body>
</html>

