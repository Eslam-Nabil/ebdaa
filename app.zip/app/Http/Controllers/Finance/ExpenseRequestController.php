<?php

namespace App\Http\Controllers\Finance;

use App\User;
use App\Models\Bond;
use App\Models\Income;
use App\Models\Invoice;
use App\Models\Expenses;
use Illuminate\Http\Request;
use App\Models\ExpenseRequest;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Resources\ExpenseRequestResource;

class ExpenseRequestController extends Controller
{
  public function __construct()
  {
  }

  public function index()
  {
    return view('portal/ExpensesRequests/index');
  }
  public function list()
  {
    try {
      $user = Auth::user();
      $where = [];
      $where[] = ['createdBy', '!=', $user->id];
      $request = ExpenseRequestResource::collection(ExpenseRequest::where($where)->get());
      return response()->json(['data' => $request]);
    } catch (\Throwable $th) {
      dd($th);
    }
  }

  public function create()
  {
    $expenses = Expenses::all();
    return view('portal/ExpensesRequests/create', compact('expenses'));
  }

  public function store(Request $request)
  {
    $user = Auth::user();
    $balance = $user->wallet->where('type','in')->sum('amount') - $user->wallet->where('type','out')->sum('amount');
    $validatedData = $request->validate(
      [
        'amount' => 'required|lte:' . $balance,
      ],
      [
        'lte'=>'Your wallet balance is  '.$balance .' amount must be smaller than your balance'
      ]
      );
      try {
        DB::beginTransaction();
        $inputs = $request->except('_token');
        if($request->amount < 1000 && $request->expense_id != '2'){
        $inputs['acceptedBy'] = User::where('group_id',1)->first()->id;
        }
      $inputs['createdBy'] = $user->id;
      ExpenseRequest::create($inputs);
      DB::commit();
      return redirect()->route('portal.request.index')->with(['success', 'added successfully']);

    } catch (\Exception $e) {
      dd($e);
    }

  }

  public function accept($id)
  {
    try {
      $request = ExpenseRequest::find($id);
      $user = Auth::user();
      $user->wallet()->create([
        'type' => 'in',
        'amount' => $request->amount
      ]);

      $request->acceptedBy = $user->id;
      $request->save();

      $creator_user = User::find($request->createdBy);
      $creator_user->wallet()->create([
        'type' => 'out',
        'amount' => $request->amount
      ]);
      return redirect()->route('portal.request.index')->with(['success', 'added successfully']);
    } catch (\Exception $e) {
      dd($e);
    }
  }

  public function print()
  {

  }
}